package com.example.currencyconverter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyconverter.databinding.ActivityMainBinding
import com.example.currencyconverter.databinding.GraphBinding

class Graph : AppCompatActivity() {

    private lateinit var binding: GraphBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = GraphBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.converter.setOnClickListener {
            startActivity(Intent(this@Graph, MainActivity::class.java))
        }


    }
}